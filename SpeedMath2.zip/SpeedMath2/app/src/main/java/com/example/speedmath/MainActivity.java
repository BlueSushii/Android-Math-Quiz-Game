package com.example.speedmath;
//Colton Dean
// C0741555
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    Button btn_start,btn_answer1, btn_answer2, btn_answer3, btn_answer4;
    TextView tv_score, tv_questions, tv_timer, tv_bottomMessage;
    ProgressBar prog_timer;

    Game g =new Game();
    int secondsRemaining = 60;


    CountDownTimer timer = new CountDownTimer(60000, 1000) {
        @Override
        public void onTick(long millisUntilFinished) {
        secondsRemaining--;
        tv_timer.setText(Integer.toString(secondsRemaining) + "sec");
        prog_timer.setProgress(60 - secondsRemaining);
        }

        @Override
        public void onFinish() {
            btn_answer1.setEnabled(false);
            btn_answer2.setEnabled(false);
            btn_answer3.setEnabled(false);
            btn_answer4.setEnabled(false);
            tv_bottomMessage.setText("Time is up!" + g.getNumberCorrect() + "/" + g.getTotatlQuestions());

            //runnable code to delay code
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    btn_start.setVisibility(View.VISIBLE);
                }
            }, 4000);

        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    btn_start   = findViewById(R.id.btn_start);
    btn_answer1 = findViewById(R.id.btn_answer1);
    btn_answer2 = findViewById(R.id.btn_answer2);
    btn_answer3= findViewById(R.id.btn_answer3);
    btn_answer4 = findViewById(R.id.btn_answer4);

    prog_timer = findViewById(R.id.prog_timer);

    tv_timer = findViewById(R.id.tv_timer);
    tv_questions = findViewById(R.id.tv_questions);
    tv_score = findViewById(R.id.tv_score);
    tv_bottomMessage = findViewById(R.id.tv_bottomMessage);

    //Starting the text boxes with a special first bit of text
        tv_timer.setText("0Sec");
        tv_questions.setText("");
        tv_bottomMessage.setText("Press Start!");
        tv_score.setText("0Pts");

        View.OnClickListener startButtonclickListener =new View.OnClickListener() {
            @Override
            //On click of the button set the start button unto invisible
            public void onClick(View v) {

                Button start_button = (Button) v;
                start_button.setVisibility(View.INVISIBLE);
                secondsRemaining =60;
                g = new Game();
                tv_score.setText("0");
                nextTurn();
                timer.start();


            }
        };
        View.OnClickListener answerButtonClickListener =new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Button buttonClicked = (Button)v;
            //just a lot of conversions.. for turning the string into a valid interger.
            int answerSelected = Integer.parseInt(buttonClicked.getText().toString());
                //Toast for debugging and making sure it still works by telling me the selected answer
                //Toast.makeText(MainActivity.this, "AnswerSelected"+answerSelected, Toast.LENGTH_SHORT).show();
            g.checkAnswer(answerSelected);
            tv_score.setText(Integer.toString(g.getScore()));
            nextTurn();
            }
        };

    btn_start.setOnClickListener(startButtonclickListener);
    //sharing the click listener between all the buttons to save on space usage.
    btn_answer1.setOnClickListener(answerButtonClickListener);
    btn_answer2.setOnClickListener(answerButtonClickListener);
    btn_answer3.setOnClickListener(answerButtonClickListener);
    btn_answer4.setOnClickListener(answerButtonClickListener);
    }
    private void nextTurn(){
        //create new Question
        //set text on answer buttons
        //start the timer

        g.makeNewQuestion();
        int [] answer = g.getCurrentQuestion().getAnswerArray();
        //setting text of the buttons
        btn_answer1.setText(Integer.toString(answer[0]));
        btn_answer2.setText(Integer.toString(answer[1]));
        btn_answer3.setText(Integer.toString(answer[2]));
        btn_answer4.setText(Integer.toString(answer[3]));

        //debugging code
        btn_answer1.setEnabled(true);
        btn_answer2.setEnabled(true);
        btn_answer3.setEnabled(true);
        btn_answer4.setEnabled(true);

        tv_questions.setText(g.getCurrentQuestion().getQuestionString());
        //sets the total questions for the text at the bottom
        tv_bottomMessage.setText(g.getNumberCorrect() + "/" + (g.getTotatlQuestions() -1));




    }

}
