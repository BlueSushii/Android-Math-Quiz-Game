package com.example.speedmath;

import java.util.Random;

public class QuestionGenerator {
    //ints needed for the question making
    private int firstNumber;
    private int secondNumber;
    private int answer;
    //store the random wrong answers to the questions for the incorrect buttons.
    private int [] answerArray;
    //which poisition is correct?
    private int answerPosition;
    //sets the difficulty basically by allowing for larger numbers to be created
    private  int difficulty;
    //Creating a string output for the question
    private String questionString;

    //generate new questions
    public QuestionGenerator(int difficulty){
    this.difficulty =difficulty;
    Random randomNumber = new Random();

    this.firstNumber = randomNumber.nextInt(difficulty);
    this.secondNumber= randomNumber.nextInt(difficulty);
    this.answer = this.firstNumber + this.secondNumber;
    this.questionString = firstNumber + " + " + secondNumber + " = ";


    this.answerPosition = randomNumber.nextInt(4);
    this.answerArray = new int[] {0,1,2,3};

    this.answerArray[0]= answer +1;
    this.answerArray[1]= answer + 10;
    this.answerArray[2]= answer -5;
    this.answerArray[3]= answer -2;
    this.answerArray = Shuffle(this.answerArray);

    answerArray[answerPosition] = answer;
    }
    //Shuffles the array so the buttons aren't in the same spot each time
    private int [] Shuffle(int[] array){
        int index, temp;
        Random random = new Random();
        for (int i = array.length -1; i>0; i--){
            index = random.nextInt(i+1);
            temp = array[index];
            array[index] =array[i];
            array[i] =temp;
        }
        return array;
    }
    public int getFirstNumber() {
        return firstNumber;
    }

    public void setFirstNumber(int firstNumber) {
        this.firstNumber = firstNumber;
    }

    public int getSecondNumber() {
        return secondNumber;
    }

    public void setSecondNumber(int secondNumber) {
        this.secondNumber = secondNumber;
    }

    public int getAnswer() {
        return answer;
    }

    public void setAnswer(int answer) {
        this.answer = answer;
    }

    public int[] getAnswerArray() {
        return answerArray;
    }

    public void setAnswerArray(int[] answerArray) {
        this.answerArray = answerArray;
    }

    public int getAnswerPosition() {
        return answerPosition;
    }

    public void setAnswerPosition(int answerPosition) {
        this.answerPosition = answerPosition;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }

    public String getQuestionString() {
        return questionString;
    }

    public void setQuestionString(String questionString) {
        this.questionString = questionString;
    }
}
