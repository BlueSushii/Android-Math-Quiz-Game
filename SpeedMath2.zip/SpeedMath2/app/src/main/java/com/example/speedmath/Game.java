package com.example.speedmath;

import java.util.ArrayList;
import java.util.List;

public class Game {

    private List<QuestionGenerator> questions;
    private int numberCorrect;
    private int numberIncorrect;
    private int totatlQuestions;
    private int score;
    private QuestionGenerator currentQuestion;

    public Game(){
        //Zeroing everything off to start
        numberCorrect =0;
        numberIncorrect=0;
        totatlQuestions=0;
        score =0;

        currentQuestion = new QuestionGenerator(10);
        questions = new ArrayList<QuestionGenerator>();
    }
    public void makeNewQuestion(){
        currentQuestion = new QuestionGenerator(totatlQuestions *2 +5);
        totatlQuestions++;
        questions.add(currentQuestion);

    }

    public boolean checkAnswer(int submittedAnswer){
        boolean isCorrect;
        if(currentQuestion.getAnswer() == submittedAnswer){
            numberCorrect++;
            isCorrect = true;

        } else{
            numberIncorrect++;
            isCorrect=false;
        }
        score = numberCorrect * 10 - numberIncorrect *30;
        return isCorrect;
    }
    public List<QuestionGenerator> getQuestions() {
        return questions;
    }

    public void setQuestions(List<QuestionGenerator> questions) {
        this.questions = questions;
    }

    public int getNumberCorrect() {
        return numberCorrect;
    }

    public void setNumberCorrect(int numberCorrect) {
        this.numberCorrect = numberCorrect;
    }

    public int getNumberIncorrect() {
        return numberIncorrect;
    }

    public void setNumberIncorrect(int numberIncorrect) {
        this.numberIncorrect = numberIncorrect;
    }

    public int getTotatlQuestions() {
        return totatlQuestions;
    }

    public void setTotatlQuestions(int totatlQuestions) {
        this.totatlQuestions = totatlQuestions;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public QuestionGenerator getCurrentQuestion() {
        return currentQuestion;
    }

    public void setCurrentQuestion(QuestionGenerator currentQuestion) {
        this.currentQuestion = currentQuestion;
    }

}
